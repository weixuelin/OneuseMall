package com.bagua.forum.ui.listener

interface ItemClickListener {
    fun onItemClick(position:Int)
    fun onLongClick(position:Int)
}