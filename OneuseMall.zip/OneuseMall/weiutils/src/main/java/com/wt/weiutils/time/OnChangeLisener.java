package com.wt.weiutils.time;

import java.util.Date;

public interface OnChangeLisener {
        void onChanged(Date date);
    }
