package com.wt.weiutils.time;

import java.util.Date;

public interface OnSureLisener {
    void onSure(Date date);
}