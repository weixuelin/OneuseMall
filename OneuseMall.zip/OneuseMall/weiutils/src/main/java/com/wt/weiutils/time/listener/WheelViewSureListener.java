package com.wt.weiutils.time.listener;

/**
 * Created by codbking on 2016/9/22.
 */

public interface WheelViewSureListener {
     public void onSure();
}
